const database = {
    entregas: [],
    historico: []
};

module.exports = database;
