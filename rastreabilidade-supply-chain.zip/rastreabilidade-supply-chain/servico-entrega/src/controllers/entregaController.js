const EntregaModel = require('../models/entrega');

const EntregaController = {
    criar: async (req, res) => {
        try {
            const { produtoId, destinatario, enderecoEntrega } = req.body;
            
            if (!produtoId || !destinatario || !enderecoEntrega) {
                return res.status(400).json({
                    sucesso: false,
                    mensagem: 'Campos obrigatórios: produtoId, destinatario, enderecoEntrega'
                });
            }
            
            const entrega = EntregaModel.criar({ produtoId, destinatario, enderecoEntrega });
            
            res.status(201).json({
                sucesso: true,
                mensagem: 'Entrega registrada',
                dados: entrega
            });
        } catch (error) {
            res.status(500).json({ sucesso: false, mensagem: error.message });
        }
    },
    
    listar: async (req, res) => {
        const entregas = EntregaModel.listarTodos();
        res.json({ sucesso: true, quantidade: entregas.length, dados: entregas });
    },
    
    buscarPorProduto: async (req, res) => {
        const entrega = EntregaModel.buscarPorProduto(req.params.produtoId);
        
        if (!entrega) {
            return res.status(404).json({ sucesso: false, mensagem: 'Entrega não encontrada' });
        }
        
        res.json({ sucesso: true, dados: entrega });
    },
    
    confirmar: async (req, res) => {
        const { recebedor, documentoRecebedor } = req.body;
        
        if (!recebedor) {
            return res.status(400).json({ sucesso: false, mensagem: 'Campo obrigatório: recebedor' });
        }
        
        const entrega = EntregaModel.confirmar(req.params.id, { recebedor, documentoRecebedor });
        
        if (!entrega) {
            return res.status(404).json({ sucesso: false, mensagem: 'Entrega não encontrada' });
        }
        
        res.json({ sucesso: true, mensagem: 'Entrega confirmada!', dados: entrega });
    }
};

module.exports = EntregaController;
