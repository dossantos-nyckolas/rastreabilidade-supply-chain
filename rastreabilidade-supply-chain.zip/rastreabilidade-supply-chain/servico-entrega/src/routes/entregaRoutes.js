const express = require('express');
const router = express.Router();
const EntregaController = require('../controllers/entregaController');

router.post('/', EntregaController.criar);
router.get('/', EntregaController.listar);
router.get('/produto/:produtoId', EntregaController.buscarPorProduto);
router.put('/:id/confirmar', EntregaController.confirmar);

module.exports = router;
