const express = require('express');
const dotenv = require('dotenv');
const entregaRoutes = require('./routes/entregaRoutes');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3003;

app.use(express.json());

app.use((req, res, next) => {
    console.log(`[ENTREGA] ${new Date().toISOString()} - ${req.method} ${req.path}`);
    next();
});

app.get('/health', (req, res) => {
    res.json({ status: 'online', servico: 'Entrega', timestamp: new Date().toISOString() });
});

app.use('/registros', entregaRoutes);

app.listen(PORT, () => {
    console.log('==================================================');
    console.log(`Servico de Entrega rodando em http://localhost:${PORT}`);
    console.log('==================================================');
});
