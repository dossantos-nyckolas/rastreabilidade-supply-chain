const { v4: uuidv4 } = require('uuid');
const db = require('../database/db');

const EntregaModel = {
    criar: (dados) => {
        const entrega = {
            id: uuidv4(),
            produtoId: dados.produtoId,
            destinatario: dados.destinatario,
            enderecoEntrega: dados.enderecoEntrega,
            status: 'em_entrega',
            dataSaida: new Date().toISOString(),
            createdAt: new Date().toISOString()
        };
        
        db.entregas.push(entrega);
        EntregaModel.registrarEvento(entrega.id, 'SAIDA', `Saiu para entrega`);
        
        return entrega;
    },
    
    listarTodos: () => db.entregas,
    
    buscarPorId: (id) => db.entregas.find(e => e.id === id),
    
    buscarPorProduto: (produtoId) => {
        const entrega = db.entregas.find(e => e.produtoId === produtoId);
        if (entrega) {
            entrega.historico = EntregaModel.buscarHistorico(entrega.id);
        }
        return entrega;
    },
    
    confirmar: (id, dados) => {
        const entrega = db.entregas.find(e => e.id === id);
        if (entrega) {
            entrega.status = 'entregue';
            entrega.recebedor = dados.recebedor;
            entrega.documentoRecebedor = dados.documentoRecebedor || '';
            entrega.dataEntrega = new Date().toISOString();
            EntregaModel.registrarEvento(id, 'ENTREGUE', `Recebido por ${dados.recebedor}`);
        }
        return entrega;
    },
    
    registrarEvento: (entregaId, evento, descricao) => {
        db.historico.push({
            entregaId,
            evento,
            descricao,
            timestamp: new Date().toISOString()
        });
    },
    
    buscarHistorico: (entregaId) => db.historico.filter(h => h.entregaId === entregaId)
};

module.exports = EntregaModel;
