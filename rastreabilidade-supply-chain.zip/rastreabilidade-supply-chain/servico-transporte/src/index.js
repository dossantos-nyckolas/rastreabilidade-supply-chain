const express = require('express');
const dotenv = require('dotenv');
const transporteRoutes = require('./routes/transporteRoutes');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3002;

app.use(express.json());

app.use((req, res, next) => {
    console.log(`[TRANSPORTE] ${new Date().toISOString()} - ${req.method} ${req.path}`);
    next();
});

app.get('/health', (req, res) => {
    res.json({ status: 'online', servico: 'Transporte', timestamp: new Date().toISOString() });
});

app.use('/registros', transporteRoutes);

app.listen(PORT, () => {
    console.log('==================================================');
    console.log(`Servico de Transporte rodando em http://localhost:${PORT}`);
    console.log('==================================================');
});
