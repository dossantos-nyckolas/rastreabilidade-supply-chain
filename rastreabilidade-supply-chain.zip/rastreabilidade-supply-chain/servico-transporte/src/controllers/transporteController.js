const TransporteModel = require('../models/transporte');

const TransporteController = {
    criar: async (req, res) => {
        try {
            const { produtoId, transportadora, motorista, veiculo, origem, destino } = req.body;
            
            if (!produtoId || !transportadora || !origem || !destino) {
                return res.status(400).json({
                    sucesso: false,
                    mensagem: 'Campos obrigatórios: produtoId, transportadora, origem, destino'
                });
            }
            
            const transporte = TransporteModel.criar({ produtoId, transportadora, motorista, veiculo, origem, destino });
            
            res.status(201).json({
                sucesso: true,
                mensagem: 'Transporte registrado',
                dados: transporte
            });
        } catch (error) {
            res.status(500).json({ sucesso: false, mensagem: error.message });
        }
    },
    
    listar: async (req, res) => {
        const transportes = TransporteModel.listarTodos();
        res.json({ sucesso: true, quantidade: transportes.length, dados: transportes });
    },
    
    buscarPorProduto: async (req, res) => {
        const transporte = TransporteModel.buscarPorProduto(req.params.produtoId);
        
        if (!transporte) {
            return res.status(404).json({ sucesso: false, mensagem: 'Transporte não encontrado' });
        }
        
        res.json({ sucesso: true, dados: transporte });
    },
    
    atualizarStatus: async (req, res) => {
        const { status, localizacao, descricao } = req.body;
        const transporte = TransporteModel.atualizarStatus(req.params.id, status, localizacao, descricao);
        
        if (!transporte) {
            return res.status(404).json({ sucesso: false, mensagem: 'Transporte não encontrado' });
        }
        
        res.json({ sucesso: true, mensagem: 'Status atualizado', dados: transporte });
    }
};

module.exports = TransporteController;
