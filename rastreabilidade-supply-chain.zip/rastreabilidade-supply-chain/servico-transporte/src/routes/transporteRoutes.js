const express = require('express');
const router = express.Router();
const TransporteController = require('../controllers/transporteController');

router.post('/', TransporteController.criar);
router.get('/', TransporteController.listar);
router.get('/produto/:produtoId', TransporteController.buscarPorProduto);
router.put('/:id/status', TransporteController.atualizarStatus);

module.exports = router;
