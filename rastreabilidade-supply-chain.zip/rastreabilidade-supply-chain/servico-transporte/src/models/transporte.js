const { v4: uuidv4 } = require('uuid');
const db = require('../database/db');

const TransporteModel = {
    criar: (dados) => {
        const transporte = {
            id: uuidv4(),
            produtoId: dados.produtoId,
            transportadora: dados.transportadora,
            motorista: dados.motorista || '',
            veiculo: dados.veiculo || '',
            origem: dados.origem,
            destino: dados.destino,
            status: 'coletado',
            dataColeta: new Date().toISOString(),
            createdAt: new Date().toISOString()
        };
        
        db.transportes.push(transporte);
        TransporteModel.registrarEvento(transporte.id, 'COLETA', `Coletado em ${dados.origem}`);
        
        return transporte;
    },
    
    listarTodos: () => db.transportes,
    
    buscarPorId: (id) => db.transportes.find(t => t.id === id),
    
    buscarPorProduto: (produtoId) => {
        const transporte = db.transportes.find(t => t.produtoId === produtoId);
        if (transporte) {
            transporte.historico = TransporteModel.buscarHistorico(transporte.id);
        }
        return transporte;
    },
    
    atualizarStatus: (id, status, localizacao, descricao) => {
        const transporte = db.transportes.find(t => t.id === id);
        if (transporte) {
            transporte.status = status;
            TransporteModel.registrarEvento(id, status.toUpperCase(), descricao || `Status: ${status}`);
        }
        return transporte;
    },
    
    registrarEvento: (transporteId, evento, descricao) => {
        db.historico.push({
            transporteId,
            evento,
            descricao,
            timestamp: new Date().toISOString()
        });
    },
    
    buscarHistorico: (transporteId) => db.historico.filter(h => h.transporteId === transporteId)
};

module.exports = TransporteModel;
