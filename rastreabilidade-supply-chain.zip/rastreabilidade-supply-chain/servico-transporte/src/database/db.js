const database = {
    transportes: [],
    historico: []
};

module.exports = database;
