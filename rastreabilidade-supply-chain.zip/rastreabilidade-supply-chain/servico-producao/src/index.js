const express = require('express');
const dotenv = require('dotenv');
const produtoRoutes = require('./routes/produtoRoutes');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

app.use(express.json());

app.use((req, res, next) => {
    console.log(`[PRODUCAO] ${new Date().toISOString()} - ${req.method} ${req.path}`);
    next();
});

app.get('/health', (req, res) => {
    res.json({ status: 'online', servico: 'Producao', timestamp: new Date().toISOString() });
});

app.use('/produtos', produtoRoutes);

app.listen(PORT, () => {
    console.log('==================================================');
    console.log(`Servico de Producao rodando em http://localhost:${PORT}`);
    console.log('==================================================');
});
