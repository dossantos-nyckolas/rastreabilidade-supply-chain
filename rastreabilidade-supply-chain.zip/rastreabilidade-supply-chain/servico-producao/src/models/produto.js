const { v4: uuidv4 } = require('uuid');
const db = require('../database/db');

const ProdutoModel = {
    criar: (dados) => {
        const produto = {
            id: uuidv4(),
            nome: dados.nome,
            descricao: dados.descricao || '',
            lote: dados.lote,
            dataProducao: dados.dataProducao || new Date().toISOString(),
            localProducao: dados.localProducao,
            status: 'produzido',
            createdAt: new Date().toISOString()
        };
        
        db.produtos.push(produto);
        
        // Registra no histórico
        ProdutoModel.registrarEvento(produto.id, 'CRIACAO', `Produto ${dados.nome} criado`);
        
        return produto;
    },
    
    listarTodos: () => {
        return db.produtos;
    },
    
    buscarPorId: (id) => {
        return db.produtos.find(p => p.id === id);
    },
    
    atualizarStatus: (id, novoStatus) => {
        const produto = db.produtos.find(p => p.id === id);
        if (produto) {
            produto.status = novoStatus;
            ProdutoModel.registrarEvento(id, 'ATUALIZACAO', `Status: ${novoStatus}`);
        }
        return produto;
    },
    
    registrarEvento: (produtoId, evento, descricao) => {
        db.historico.push({
            id: uuidv4(),
            produtoId,
            evento,
            descricao,
            timestamp: new Date().toISOString()
        });
    },
    
    buscarHistorico: (produtoId) => {
        return db.historico.filter(h => h.produtoId === produtoId);
    }
};

module.exports = ProdutoModel;
