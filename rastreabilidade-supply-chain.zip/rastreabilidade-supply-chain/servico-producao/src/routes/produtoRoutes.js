const express = require('express');
const router = express.Router();
const ProdutoController = require('../controllers/produtoController');

router.post('/', ProdutoController.criar);
router.get('/', ProdutoController.listar);
router.get('/:id', ProdutoController.buscarPorId);
router.get('/:id/rastreabilidade', ProdutoController.rastreabilidade);

module.exports = router;
