/**
 * Banco de dados em memória (JSON)
 * Simples e funcional para fins acadêmicos
 */

const database = {
    produtos: [],
    historico: []
};

module.exports = database;
