const ProdutoModel = require('../models/produto');
const axios = require('axios');

const ProdutoController = {
    criar: async (req, res) => {
        try {
            const { nome, descricao, lote, dataProducao, localProducao } = req.body;
            
            if (!nome || !lote || !localProducao) {
                return res.status(400).json({
                    sucesso: false,
                    mensagem: 'Campos obrigatórios: nome, lote, localProducao'
                });
            }
            
            const produto = ProdutoModel.criar({ nome, descricao, lote, dataProducao, localProducao });
            
            res.status(201).json({
                sucesso: true,
                mensagem: 'Produto criado com sucesso',
                dados: produto
            });
        } catch (error) {
            res.status(500).json({ sucesso: false, mensagem: error.message });
        }
    },
    
    listar: async (req, res) => {
        try {
            const produtos = ProdutoModel.listarTodos();
            res.json({ sucesso: true, quantidade: produtos.length, dados: produtos });
        } catch (error) {
            res.status(500).json({ sucesso: false, mensagem: error.message });
        }
    },
    
    buscarPorId: async (req, res) => {
        try {
            const produto = ProdutoModel.buscarPorId(req.params.id);
            
            if (!produto) {
                return res.status(404).json({ sucesso: false, mensagem: 'Produto não encontrado' });
            }
            
            res.json({ sucesso: true, dados: produto });
        } catch (error) {
            res.status(500).json({ sucesso: false, mensagem: error.message });
        }
    },
    
    rastreabilidade: async (req, res) => {
        try {
            const produto = ProdutoModel.buscarPorId(req.params.id);
            
            if (!produto) {
                return res.status(404).json({ sucesso: false, mensagem: 'Produto não encontrado' });
            }
            
            const historico = ProdutoModel.buscarHistorico(req.params.id);
            
            // Busca dados de transporte
            let transporte = null;
            try {
                const resp = await axios.get(`${process.env.TRANSPORTE_URL}/registros/produto/${req.params.id}`);
                transporte = resp.data.dados;
            } catch (e) { }
            
            // Busca dados de entrega
            let entrega = null;
            try {
                const resp = await axios.get(`${process.env.ENTREGA_URL}/registros/produto/${req.params.id}`);
                entrega = resp.data.dados;
            } catch (e) { }
            
            // Determina status atual
            let statusAtual = 'PRODUZIDO';
            if (entrega && entrega.status === 'entregue') statusAtual = 'ENTREGUE';
            else if (entrega) statusAtual = 'EM ENTREGA';
            else if (transporte && transporte.status === 'em_transito') statusAtual = 'EM TRANSITO';
            else if (transporte) statusAtual = 'COLETADO';
            
            res.json({
                sucesso: true,
                dados: {
                    produto: { ...produto, statusAtual },
                    etapas: {
                        producao: { status: 'concluido', historico },
                        transporte: transporte || { status: 'pendente' },
                        entrega: entrega || { status: 'pendente' }
                    }
                }
            });
        } catch (error) {
            res.status(500).json({ sucesso: false, mensagem: error.message });
        }
    }
};

module.exports = ProdutoController;
