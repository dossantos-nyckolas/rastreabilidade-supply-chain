const express = require('express');
const axios = require('axios');
const router = express.Router();

const SERVICOS = {
    producao: process.env.PRODUCAO_URL || 'http://localhost:3001',
    transporte: process.env.TRANSPORTE_URL || 'http://localhost:3002',
    entrega: process.env.ENTREGA_URL || 'http://localhost:3003'
};

const encaminhar = async (servicoUrl, path, req, res) => {
    try {
        const url = `${servicoUrl}${path}`;
        console.log(`[PROXY] ${req.method} ${url}`);
        
        const config = {
            method: req.method,
            url,
            headers: { 'Content-Type': 'application/json' }
        };
        
        if (['POST', 'PUT', 'PATCH'].includes(req.method)) {
            config.data = req.body;
        }
        
        const resposta = await axios(config);
        res.status(resposta.status).json(resposta.data);
        
    } catch (error) {
        if (error.response) {
            res.status(error.response.status).json(error.response.data);
        } else if (error.code === 'ECONNREFUSED') {
            res.status(503).json({ sucesso: false, mensagem: 'Serviço indisponível' });
        } else {
            res.status(500).json({ sucesso: false, mensagem: error.message });
        }
    }
};

// Rotas de Produção
router.post('/producao/produtos', (req, res) => encaminhar(SERVICOS.producao, '/produtos', req, res));
router.get('/producao/produtos', (req, res) => encaminhar(SERVICOS.producao, '/produtos', req, res));
router.get('/producao/produtos/:id', (req, res) => encaminhar(SERVICOS.producao, `/produtos/${req.params.id}`, req, res));
router.get('/producao/produtos/:id/rastreabilidade', (req, res) => encaminhar(SERVICOS.producao, `/produtos/${req.params.id}/rastreabilidade`, req, res));

// Rotas de Transporte
router.post('/transporte/registros', (req, res) => encaminhar(SERVICOS.transporte, '/registros', req, res));
router.get('/transporte/registros', (req, res) => encaminhar(SERVICOS.transporte, '/registros', req, res));
router.get('/transporte/registros/produto/:produtoId', (req, res) => encaminhar(SERVICOS.transporte, `/registros/produto/${req.params.produtoId}`, req, res));
router.put('/transporte/registros/:id/status', (req, res) => encaminhar(SERVICOS.transporte, `/registros/${req.params.id}/status`, req, res));

// Rotas de Entrega
router.post('/entrega/registros', (req, res) => encaminhar(SERVICOS.entrega, '/registros', req, res));
router.get('/entrega/registros', (req, res) => encaminhar(SERVICOS.entrega, '/registros', req, res));
router.get('/entrega/registros/produto/:produtoId', (req, res) => encaminhar(SERVICOS.entrega, `/registros/produto/${req.params.produtoId}`, req, res));
router.put('/entrega/registros/:id/confirmar', (req, res) => encaminhar(SERVICOS.entrega, `/registros/${req.params.id}/confirmar`, req, res));

module.exports = router;
