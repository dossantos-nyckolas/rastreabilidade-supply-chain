const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const authMiddleware = require('./middleware/auth');
const proxyRoutes = require('./routes/proxy');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Log de requisições
app.use((req, res, next) => {
    console.log(`[GATEWAY] ${new Date().toISOString()} - ${req.method} ${req.path}`);
    next();
});

// Health check
app.get('/health', (req, res) => {
    res.json({ 
        status: 'online', 
        servico: 'API Gateway',
        timestamp: new Date().toISOString()
    });
});

// Login
app.post('/auth/login', (req, res) => {
    const { usuario, senha } = req.body;
    
    const usuariosValidos = {
        'admin': 'admin123',
        'operador': 'operador123'
    };
    
    if (usuariosValidos[usuario] && usuariosValidos[usuario] === senha) {
        const jwt = require('jsonwebtoken');
        const token = jwt.sign(
            { usuario, perfil: usuario === 'admin' ? 'administrador' : 'operador' },
            process.env.JWT_SECRET,
            { expiresIn: '1h' }
        );
        
        res.json({
            sucesso: true,
            mensagem: 'Login realizado com sucesso',
            token,
            expiraEm: '1 hora'
        });
    } else {
        res.status(401).json({
            sucesso: false,
            mensagem: 'Credenciais inválidas'
        });
    }
});

// Rotas protegidas
app.use('/api', authMiddleware, proxyRoutes);

// Erro 404
app.use((req, res) => {
    res.status(404).json({ sucesso: false, mensagem: 'Rota não encontrada' });
});

app.listen(PORT, () => {
    console.log('==================================================');
    console.log(`API Gateway rodando em http://localhost:${PORT}`);
    console.log('==================================================');
});
