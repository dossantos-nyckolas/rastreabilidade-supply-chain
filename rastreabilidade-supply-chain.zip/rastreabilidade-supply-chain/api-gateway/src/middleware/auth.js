const jwt = require('jsonwebtoken');

const authMiddleware = (req, res, next) => {
    const authHeader = req.headers.authorization;
    
    if (!authHeader) {
        return res.status(401).json({
            sucesso: false,
            mensagem: 'Token não fornecido',
            dica: 'Use: Authorization: Bearer <seu_token>'
        });
    }
    
    const partes = authHeader.split(' ');
    
    if (partes.length !== 2 || partes[0] !== 'Bearer') {
        return res.status(401).json({
            sucesso: false,
            mensagem: 'Formato de token inválido'
        });
    }
    
    const token = partes[1];
    
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.usuario = decoded;
        next();
    } catch (error) {
        return res.status(401).json({
            sucesso: false,
            mensagem: error.name === 'TokenExpiredError' ? 'Token expirado' : 'Token inválido'
        });
    }
};

module.exports = authMiddleware;
